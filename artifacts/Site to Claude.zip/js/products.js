window.PRODUCTS = [
  {
    id: "blueberry",
    name: "Blueberry Jam",
    category: "Jam",
    image: "/images/blueberry-jam.jpg",
    description:
      "Pure-premium blueberry jam from locally sourced fruit, made in small batches the way the family has always done it.",
    prices: { "8 oz": 12, "12 oz": 16 },
  },
  {
    id: "strawberry-champagne",
    name: "Strawberry Champagne Jam",
    category: "Jam",
    image: "/images/jar-placeholder.jpg",
    description:
      "Sun-ripened strawberries finished with champagne. Bright, floral, and meant for toast or a cheese board.",
    prices: { "8 oz": 14, "12 oz": 18 },
  },
  {
    id: "bourbon-peach",
    name: "Bourbon Peach Preserve",
    category: "Jam",
    image: "/images/jar-placeholder.jpg",
    description:
      "Southern peaches with bourbon and vanilla. A limited-style preserve from fresh, local fruit.",
    prices: { "8 oz": 16, "12 oz": 20 },
  },
  {
    id: "pickled-okra",
    name: "Signature Pickled Okra & Veggies",
    category: "Pickled Veggies",
    image: "/images/jar-placeholder.jpg",
    description:
      "Crisp farm vegetables with garlic, dill, and a gentle kick. The jars wear the same Queen E label as the jams.",
    prices: { "8 oz": 15, "12 oz": 18 },
  },
];
