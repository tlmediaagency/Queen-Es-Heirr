(function () {
  const menuBtn = document.querySelector("[data-menu-btn]");
  const menu = document.querySelector("[data-menu]");
  if (menuBtn && menu) {
    menuBtn.addEventListener("click", function () {
      const open = menu.classList.toggle("is-open");
      menuBtn.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  document.querySelectorAll("[data-tabs]").forEach(function (tabs) {
    const buttons = tabs.querySelectorAll("[data-tab]");
    const panels = tabs.parentElement.querySelectorAll("[data-panel]");
    buttons.forEach(function (btn) {
      btn.addEventListener("click", function () {
        const name = btn.getAttribute("data-tab");
        buttons.forEach(function (b) {
          b.classList.toggle("is-active", b === btn);
        });
        panels.forEach(function (panel) {
          panel.hidden = panel.getAttribute("data-panel") !== name;
        });
      });
    });
  });

  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const coarse = window.matchMedia("(pointer: coarse)").matches;
  if (!reduce && !coarse) {
    const count = 7;
    const mouse = { x: innerWidth / 2, y: innerHeight / 2 };
    const spots = [];
    const nodes = [];
    for (let i = 0; i < count; i++) {
      spots.push({ x: mouse.x, y: mouse.y });
      const span = document.createElement("span");
      span.className = "crown-trail";
      span.setAttribute("aria-hidden", "true");
      span.style.opacity = String((count - i) / count);
      span.innerHTML =
        '<svg viewBox="0 0 24 24" width="14" height="14"><path d="M3 17 L5 8 L9 12 L12 6 L15 12 L19 8 L21 17 Z"/><rect x="4" y="18" width="16" height="2" rx="1"/></svg>';
      document.body.appendChild(span);
      nodes.push(span);
    }
    addEventListener("mousemove", function (e) {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    });
    (function tick() {
      let x = mouse.x;
      let y = mouse.y;
      spots.forEach(function (pos, i) {
        pos.x += (x - pos.x) * 0.35;
        pos.y += (y - pos.y) * 0.35;
        x = pos.x;
        y = pos.y;
        nodes[i].style.transform =
          "translate(" + pos.x + "px," + pos.y + "px) translate(-50%,-50%)";
      });
      requestAnimationFrame(tick);
    })();
  }

  const KEY = "queen-e-cart";
  function loadCart() {
    try {
      return JSON.parse(localStorage.getItem(KEY) || "[]");
    } catch (e) {
      return [];
    }
  }
  function saveCart(lines) {
    localStorage.setItem(KEY, JSON.stringify(lines));
  }
  function count(lines) {
    return lines.reduce(function (n, l) {
      return n + l.qty;
    }, 0);
  }
  function money(n) {
    return n.toLocaleString("en-US", { style: "currency", currency: "USD" });
  }
  function findProduct(id) {
    return (window.PRODUCTS || []).find(function (p) {
      return p.id === id;
    });
  }

  const panel = document.querySelector("[data-cart-panel]");
  const countEl = document.querySelector("[data-cart-count]");
  const linesEl = document.querySelector("[data-cart-lines]");
  const subEl = document.querySelector("[data-cart-subtotal]");

  function render() {
    const lines = loadCart();
    if (countEl) countEl.textContent = String(count(lines));
    if (!linesEl || !subEl) return;
    linesEl.innerHTML = "";
    let sub = 0;
    if (!lines.length) {
      linesEl.innerHTML = '<p class="muted">Your bag is empty.</p>';
    }
    lines.forEach(function (line) {
      const product = findProduct(line.id);
      const price = product && product.prices[line.size] ? product.prices[line.size] : 0;
      sub += price * line.qty;
      const row = document.createElement("div");
      row.className = "cart-line";
      row.innerHTML =
        "<div><strong>" +
        (product ? product.name : line.id) +
        "</strong><br><span class='muted'>" +
        line.size +
        "</span></div>" +
        "<div class='qty'><button type='button' data-dec>-</button><span>" +
        line.qty +
        "</span><button type='button' data-inc>+</button></div>" +
        "<div>" +
        money(price * line.qty) +
        "</div>";
      row.querySelector("[data-dec]").addEventListener("click", function () {
        change(line.id, line.size, -1);
      });
      row.querySelector("[data-inc]").addEventListener("click", function () {
        change(line.id, line.size, 1);
      });
      linesEl.appendChild(row);
    });
    subEl.textContent = money(sub);
  }

  function change(id, size, delta) {
    const lines = loadCart();
    const line = lines.find(function (l) {
      return l.id === id && l.size === size;
    });
    if (!line) return;
    line.qty += delta;
    saveCart(
      lines.filter(function (l) {
        return l.qty > 0;
      }),
    );
    render();
  }

  document.querySelectorAll("[data-add]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      const card = btn.closest("[data-product]");
      const id = btn.getAttribute("data-id");
      const size = card.querySelector("[data-size]").value;
      const lines = loadCart();
      const existing = lines.find(function (l) {
        return l.id === id && l.size === size;
      });
      if (existing) existing.qty += 1;
      else lines.push({ id: id, size: size, qty: 1 });
      saveCart(lines);
      render();
      if (panel) panel.classList.add("is-open");
    });
  });

  document.querySelectorAll("[data-cart-open]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      if (panel) panel.classList.add("is-open");
    });
  });
  document.querySelectorAll("[data-cart-close]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      if (panel) panel.classList.remove("is-open");
    });
  });

  const shop = document.querySelector("[data-shop]");
  if (shop && window.PRODUCTS) {
    shop.innerHTML = window.PRODUCTS.map(function (p) {
      const sizes = Object.keys(p.prices)
        .map(function (size) {
          return (
            '<option value="' +
            size +
            '">' +
            size +
            " · " +
            money(p.prices[size]) +
            "</option>"
          );
        })
        .join("");
      return (
        '<article class="card" data-product>' +
        '<img src="' +
        p.image +
        '" alt="' +
        p.name +
        '">' +
        "<div class='card-body'>" +
        "<p class='kicker'>" +
        p.category +
        "</p>" +
        "<h3>" +
        p.name +
        "</h3>" +
        "<p>" +
        p.description +
        "</p>" +
        '<label class="field">Size<select data-size>' +
        sizes +
        "</select></label>" +
        '<button type="button" class="btn" data-add data-id="' +
        p.id +
        '">Add to Cart</button>' +
        "</div></article>"
      );
    }).join("");
    document.querySelectorAll("[data-add]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const card = btn.closest("[data-product]");
        const id = btn.getAttribute("data-id");
        const size = card.querySelector("[data-size]").value;
        const lines = loadCart();
        const existing = lines.find(function (l) {
          return l.id === id && l.size === size;
        });
        if (existing) existing.qty += 1;
        else lines.push({ id: id, size: size, qty: 1 });
        saveCart(lines);
        render();
        if (panel) panel.classList.add("is-open");
      });
    });
  }

  render();
})();
